define({
  "name": "Rest API InterPhoto",
  "version": "0.0.0",
  "description": "apiDoc for Rest API",
  "title": "Rest API InterPhoto",
  "url": "http://127.0.0.1/interPhoto/web/index.php",
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2016-04-28T10:58:53.535Z",
    "url": "http://apidocjs.com",
    "version": "0.16.1"
  }
});
